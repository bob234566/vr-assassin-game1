import React from 'react';

const PauseMenu = ({ cheats, toggleCheat, resume }: any) => {
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.8)', color: 'white', padding: '20px'
    }}>
      <h2>Paused</h2>
      <button onClick={resume}>Resume Game</button>
      <div>
        <h3>Cheats</h3>
        <label>
          <input
            type="checkbox"
            checked={cheats.infiniteAmmo}
            onChange={() => toggleCheat('infiniteAmmo')}
          />
          Infinite Ammo
        </label><br />
        <label>
          <input
            type="checkbox"
            checked={cheats.autoSilencer}
            onChange={() => toggleCheat('autoSilencer')}
          />
          Auto Silencer
        </label>
      </div>
    </div>
  );
};

export default PauseMenu;
