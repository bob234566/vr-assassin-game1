# VR Assassin Game

This is a simple starter VR-compatible browser game using React, Vite, and WebXR APIs. Includes a cheat-enabled pause menu.

## Run Locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

- Go to [vercel.com](https://vercel.com)
- Import manually
- Drag and drop this folder or zip

Enjoy in VR!
