import React, { useState } from 'react';
import Game from './components/Game';
import PauseMenu from './components/PauseMenu';

const App = () => {
  const [paused, setPaused] = useState(false);
  const [cheats, setCheats] = useState({
    infiniteAmmo: false,
    autoSilencer: false,
  });

  const togglePause = () => setPaused(!paused);
  const toggleCheat = (cheat: keyof typeof cheats) => {
    setCheats(prev => ({ ...prev, [cheat]: !prev[cheat] }));
  };

  return (
    <>
      {paused && <PauseMenu cheats={cheats} toggleCheat={toggleCheat} resume={togglePause} />}
      <Game paused={paused} cheats={cheats} pause={togglePause} />
    </>
  );
};

export default App;
