import React, { useEffect } from 'react';

const Game = ({ paused, cheats, pause }: any) => {
  useEffect(() => {
    if (cheats.infiniteAmmo) {
      console.log("Infinite ammo enabled");
    }
    if (cheats.autoSilencer) {
      console.log("Auto silencer enabled");
    }
  }, [cheats]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') pause();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [pause]);

  return (
    <div style={{ color: 'white', padding: '20px' }}>
      <h1>VR Assassin Game</h1>
      <p>{paused ? 'Paused' : 'Running'}</p>
    </div>
  );
};

export default Game;
